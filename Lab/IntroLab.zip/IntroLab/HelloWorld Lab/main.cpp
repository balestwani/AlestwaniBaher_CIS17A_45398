
/* 
 * File:   main.cpp
 * Author: Baher Alestwani
 * Created on July 14, 2021, 4:10 PM
 * Purpose: Hello World Program Intro Lab
 */

#include <cstdlib>
#include <iostream>
using namespace std;


int main(int argc, char** argv) {

    cout << "Hello World!"<< endl;
    
    return 0;
}

